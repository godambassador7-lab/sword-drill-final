﻿Miqra according to the Mesorah
	2/19/2014

Text of the Hebrew bible, compiled by Seth (Avi) Kadish.  This OSIS
version preserves the Hebrew bible structure.  It is divided into
three parts.

The Torah consists of the five books of Moses.  These are marked up
in sections, corresponding to the weekly Torah readings.  Chapter and
verse divisions are added as milestones.

The Prophets begin with Joshua, Judges, Samuel and Kings.  These last
two contain the first and second books of each, within the group.
Then the Prophets continue with Isaiah, Jeremiah, Ezekiel and the
Twelve, which is made up of the twelve “minor” prophets.

The Writings begins with the poetic books, Psalms, Proverbs and Job,
followed by the Scrolls, Song of Songs, Ruth, Lamentations, Ecclesiastes
and Esther.  Then there are Daniel, Ezra and Chronicles.  Ezra contains
both Ezra and Nehemiah.  Chronicles has both first and second books.

The Hebrew titles have been preserved throughout, in the title elements.
The Hebrew chapter and verse numbers are maintained in the n attribute
of the opening chapter and verse tags.

For a more detailed description of the text and to read it online, see
http://en.wikisource.org/wiki/User:Dovi/Miqra_according_to_the_Mesorah

This text is released under the Creative Commons Attribution-ShareAlike
3.0 Unported license, http://creativecommons.org/licenses/by-sa/3.0/.
