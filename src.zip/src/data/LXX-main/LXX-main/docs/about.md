provenance information will come here

http://ccat.sas.upenn.edu/gopher/text/religion/biblical/lxxmorph/
