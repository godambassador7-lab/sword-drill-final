information about all features and node types comes here
