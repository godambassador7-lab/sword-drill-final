// App.js — Sword Drill (re-architected single-file version)
// ---------------------------------------------------------
// This rebuild keeps feature parity with your legacy 4k-line App.js but splits
// concerns cleanly inside one file. It preserves Firebase auth, quiz types,
// spaced repetition, mastery, achievements, Ancient Study, S.H.A.R.P. settings,
// streaks, enhanced review, and SharpAssistant/Analytics integration.
//
// 🔧 IMPORTANT: Verify/adjust the import paths to your project structure.
// Some services are optional; guarded fallbacks are provided where sensible.

import React, { useEffect, useMemo, useRef, useState, Suspense } from "react";
import {
  Flame,
  HelpCircle,
  Home,
  LogIn,
  LogOut,
  Menu,
  Settings as SettingsIcon,
  Target,
  Trophy,
  BookOpen,
  BookMarked,
  Shield,
  Sparkles,
  BrainCircuit,
  Compass,
  CheckCircle2,
  XCircle,
  ChevronDown,
  ChevronRight,
  CalendarDays,
  Feather,
  Database,
} from "lucide-react";

// ---- External (project) imports: adjust paths as needed --------------------
/** Firebase Auth */
import {
  signUp as fbSignUp,
  signIn as fbSignIn,
  signOut as fbSignOut,
  onAuthChange,
} from "./services/authService";

/** Firestore & persistence */
import {
  subscribeToUserProgress,
  getUserData,
  addQuizResult,
  updateUserProgress,
} from "./services/dbService";

/** Bible services (local only) */
import { getRandomLocalVerse } from "./services/localBibleProvider";

/** Streak helper (optional) */
// import { StreakManager } from "./services/StreakManager";

/** External assistants (already in your project) */
import SharpAssistant from "./services/SharpAssistant";
import AnalyticsModal from "./services/Analyticsmodal";

/** Daily verses */
import { getDailyVerse } from "./dailyVerses";

/** Version & styles */
const APP_VERSION = "1.0.0";
import "./App.css";

// ---------------------------------------------------------------------------
// 1) GLOBAL DATA
// ---------------------------------------------------------------------------

// Minimal canonical fallback database (expand with your real set)
const VERSE_DATABASE = [
  { ref: "John 3:16", text: "For God so loved the world...", book: "John", topic: "Gospel", difficulty: "Beginner" },
  { ref: "Psalm 23:1", text: "The Lord is my shepherd...", book: "Psalms", topic: "Comfort", difficulty: "Beginner" },
  { ref: "Romans 8:28", text: "And we know that all things work together...", book: "Romans", topic: "Promise", difficulty: "Intermediate" },
  { ref: "Proverbs 3:5-6", text: "Trust in the LORD with all thine heart...", book: "Proverbs", topic: "Wisdom", difficulty: "Beginner" },
  { ref: "Philippians 4:13", text: "I can do all things through Christ...", book: "Philippians", topic: "Strength", difficulty: "Beginner" },
  { ref: "Genesis 1:1", text: "In the beginning God created...", book: "Genesis", topic: "Creation", difficulty: "Beginner" },
  { ref: "Isaiah 53:5", text: "But he was wounded for our transgressions...", book: "Isaiah", topic: "Messiah", difficulty: "Advanced" },
  { ref: "Ephesians 2:8-9", text: "For by grace are ye saved through faith...", book: "Ephesians", topic: "Grace", difficulty: "Intermediate" },
  { ref: "Matthew 28:19", text: "Go ye therefore, and teach all nations...", book: "Matthew", topic: "Commission", difficulty: "Intermediate" },
  { ref: "Hebrews 11:1", text: "Now faith is the substance of things hoped for...", book: "Hebrews", topic: "Faith", difficulty: "Intermediate" },
];

const QUIZ_POINTS = {
  "fill-blank": 100,
  "multiple-choice": 75,
  "reference-recall": 150,
};

const ACHIEVEMENTS = {
  apprentice: [
    { key: "firstLogin", name: "First Login", desc: "Welcome to Sword Drill!", icon: "✨" },
    { key: "firstQuiz", name: "First Quiz", desc: "Complete your first quiz.", icon: "🗡️" },
    { key: "devotionalRead", name: "Daily Motivation", desc: "Read today’s verse.", icon: "📖" },
  ],
  squire: [
    { key: "streak3", name: "Streak: 3 Days", desc: "Keep steady for three days.", icon: "🔥" },
    { key: "points1k", name: "1,000 Points", desc: "Earn 1,000 total points.", icon: "🏅" },
  ],
  knight: [
    { key: "master5", name: "Master 5 Verses", desc: "Master five verses.", icon: "🛡️" },
    { key: "streak7", name: "Streak: 7 Days", desc: "One full week on fire.", icon: "🔥" },
  ],
  champion: [
    { key: "points10k", name: "10,000 Points", desc: "Accumulate serious points.", icon: "🏆" },
  ],
  scholar: [
    { key: "ancientUnlocked", name: "Ancient Study Unlocked", desc: "Unlock Ancient Study.", icon: "📜" },
  ],
};

const CATEGORY_CONFIG = {
  groupings: ["difficulty", "topic", "book"],
  difficulties: ["Beginner", "Intermediate", "Advanced"],
  topics: ["Gospel", "Faith", "Wisdom", "Comfort", "Strength", "Creation", "Messiah", "Grace", "Commission"],
};

const ANCIENT_TEXTS = {
  lxx: {
    name: "Septuagint (LXX)",
    sample: [
      {
        ref: "Psalm 23:1 (22:1 LXX)",
        greek: "Κύριος ποιμαίνει με, καὶ οὐδέν με ὑστερήσει.",
        translit: "Kyrios poimainei me, kai ouden me ysterēsei.",
        english: "The Lord shepherds me, and I shall lack nothing.",
      },
    ],
  },
  sinaiticus: {
    name: "Codex Sinaiticus",
    sample: [
      {
        ref: "John 1:1",
        greek: "Ἐν ἀρχῇ ἦν ὁ Λόγος...",
        translit: "En archē ēn ho Logos...",
        english: "In the beginning was the Word...",
      },
    ],
  },
};

// ---------------------------------------------------------------------------
// 2) HELPERS
// ---------------------------------------------------------------------------

const todayISO = () => new Date().toISOString().slice(0, 10);

function calculateStreak(prevDateISO, lastDateISO) {
  // prevDateISO: last recorded streak date; lastDateISO: "today"
  if (!prevDateISO) return { streak: 1, updatedDate: lastDateISO };
  const prev = new Date(prevDateISO + "T00:00:00");
  const last = new Date(lastDateISO + "T00:00:00");
  const diff = Math.round((last - prev) / 86400000);
  if (diff <= 0) return { streak: undefined, updatedDate: prevDateISO }; // same day or earlier
  if (diff === 1) return { streak: "increment", updatedDate: lastDateISO };
  return { streak: "reset", updatedDate: lastDateISO };
}

async function fetchVerseWithRetry({ translation = "KJV", difficulty = "Beginner" }) {
  try {
    // Use only local verses - no API calls
    const verse = await getRandomLocalVerse(translation);
    if (verse) {
      return {
        reference: verse.reference || verse.ref,
        text: verse.text,
        book: verse.book,
        difficulty: difficulty // Add difficulty from user settings
      };
    }
    return null;
  } catch {
    return null;
  }
}

function getFallbackVerse(userData) {
  // Simple fallback: pick a verse whose nextReview <= today, else random from local database
  const today = todayISO();
  const due = Object.entries(userData.verseProgress || {}).find(([, p]) => (p?.nextReview || today) <= today);
  if (due) {
    const [ref] = due;
    const item = VERSE_DATABASE.find(v => v.ref === ref) || VERSE_DATABASE[0];
    return {
      reference: item.ref,
      text: item.text,
      book: item.book,
      topic: item.topic,
      difficulty: item.difficulty
    };
  }
  const randomVerse = VERSE_DATABASE[Math.floor(Math.random() * VERSE_DATABASE.length)];
  return {
    reference: randomVerse.ref,
    text: randomVerse.text,
    book: randomVerse.book,
    topic: randomVerse.topic,
    difficulty: randomVerse.difficulty
  };
}

// Simple similarity (token overlap) 0..1
function calculateSimilarity(a, b) {
  const na = (a || "").toLowerCase().replace(/[^a-z0-9\s]/g, "");
  const nb = (b || "").toLowerCase().replace(/[^a-z0-9\s]/g, "");
  const A = new Set(na.split(/\s+/).filter(Boolean));
  const B = new Set(nb.split(/\s+/).filter(Boolean));
  if (!A.size || !B.size) return 0;
  let inter = 0;
  for (const t of A) if (B.has(t)) inter++;
  return inter / Math.max(A.size, B.size);
}

// fuzzy answer matcher; handles archaic forms lightly
function normalizeArchaic(str) {
  return (str || "")
    .toLowerCase()
    .replace(/\bthee\b/g, "you")
    .replace(/\bthou\b/g, "you")
    .replace(/\bthy\b/g, "your")
    .replace(/\bshalt\b/g, "shall")
    .replace(/[^\w\s]/g, "");
}

function checkAnswerMatch(userAnswer, correct) {
  const ua = normalizeArchaic(userAnswer);
  const ca = normalizeArchaic(correct);
  if (ua === ca) return true;
  return calculateSimilarity(ua, ca) >= 0.8;
}

// spaced repetition interval calculation (SM-like lite)
function getNextInterval(prev = 0, correct = true) {
  if (!correct) return 1; // 1 day if wrong
  if (prev === 0) return 1;
  if (prev === 1) return 3;
  return Math.round(prev * 1.7);
}

// Mastery bucket
function masteryFromStats({ accuracy = 0, reps = 0 }) {
  if (reps >= 5 && accuracy >= 0.9) return "Mastered";
  if (reps >= 3 && accuracy >= 0.75) return "Proficient";
  if (reps >= 1 && accuracy >= 0.5) return "Learning";
  return "Struggling";
}

// Utility
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));

// ---------------------------------------------------------------------------
// 3) COMPONENTS
// ---------------------------------------------------------------------------

/** Error Boundary */
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-900 text-slate-100 flex items-center justify-center p-6">
          <div className="max-w-lg w-full rounded-2xl border border-rose-500/30 bg-slate-800/50 p-6">
            <div className="flex items-center gap-3 mb-4">
              <XCircle className="text-rose-400" />
              <h2 className="text-xl font-bold">Something went wrong</h2>
            </div>
            <p className="text-slate-300 mb-4">
              An unexpected error occurred while rendering Sword Drill. You can try reloading or dismissing the error.
            </p>
            <div className="flex gap-3">
              <button
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500"
                onClick={() => window.location.reload()}
              >
                Reload
              </button>
              <button
                className="px-4 py-2 rounded-xl bg-slate-700 hover:bg-slate-600"
                onClick={() => this.setState({ hasError: false, error: null })}
              >
                Dismiss
              </button>
            </div>
            <details className="mt-4 text-xs opacity-70">
              <summary>Error details</summary>
              <pre className="whitespace-pre-wrap">{String(this.state.error)}</pre>
            </details>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

/** Streak flames */
function StreakDisplay({ streak = 0 }) {
  const level =
    streak >= 30 ? "to-yellow-300" :
    streak >= 14 ? "to-amber-300" :
    streak >= 7  ? "to-orange-300" :
    "to-red-300";
  const flames = clamp(streak, 0, 5);
  return (
    <div className="flex items-center gap-2">
      {Array.from({ length: flames }).map((_, i) => (
        <Flame key={i} className={`drop-shadow [filter:brightness(1.1)] bg-gradient-to-b from-orange-600 ${level} rounded-full p-1`} />
      ))}
      <span className="text-sm text-slate-300">{streak} day{streak === 1 ? "" : "s"}</span>
    </div>
  );
}

/** Help / Docs */
function HelpView() {
  const panels = [
    { title: "Getting Started", icon: <Home size={16} />, body: "Create an account, pick a translation, and start a quiz. Your streak grows daily." },
    { title: "Quiz Types", icon: <Target size={16} />, body: "Fill-in-the-Blank, Multiple Choice, Reference Recall. Answers use fuzzy matching." },
    { title: "Difficulty Levels", icon: <Shield size={16} />, body: "Beginner / Intermediate / Advanced. Advanced unlocks Ancient Study." },
    { title: "Ancient Study", icon: <BookOpen size={16} />, body: "Browse LXX / Sinaiticus, show Greek, transliteration, English, and compare." },
    { title: "Spaced Repetition", icon: <CalendarDays size={16} />, body: "Correct = longer interval; wrong = review sooner. Mastery grows with accuracy." },
    { title: "Achievements", icon: <Trophy size={16} />, body: "Unlock tiers by streaks, points, mastery, and feature unlocks." },
    { title: "Mastery List", icon: <Database size={16} />, body: "Group by difficulty, topic, or book. Inspect accuracy per quiz type." },
    { title: "Settings & Customization", icon: <SettingsIcon size={16} />, body: "Translations, Apocrypha toggle, Creed of the Way, Ancient Study unlock." },
    { title: "Tips for Success", icon: <Sparkles size={16} />, body: "Short daily sessions beat marathons. Mix quiz types. Review wrong answers." },
    { title: "What's New", icon: <Feather size={16} />, body: `App version ${APP_VERSION}. Enhanced Review mode & analytics upgrades.` },
    { title: "Support", icon: <HelpCircle size={16} />, body: "Questions or feedback? Use the Settings contact/donation section." },
  ];
  return (
    <div className="space-y-3">
      {panels.map((p, idx) => (
        <details key={idx} className="group rounded-xl border border-amber-500/20 bg-slate-800/40 p-4">
          <summary className="flex items-center gap-2 cursor-pointer">
            <span className="inline-flex items-center justify-center w-6 h-6">{p.icon}</span>
            <span className="font-semibold">{p.title}</span>
            <ChevronDown className="ml-auto transition-transform group-open:rotate-180" size={18} />
          </summary>
          <div className="mt-3 text-slate-300">{p.body}</div>
        </details>
      ))}
    </div>
  );
}

/** Ancient Study */
function AncientStudyView() {
  const [mode, setMode] = useState("Browse"); // Browse | Search | Compare
  const [showGreek, setShowGreek] = useState(true);
  const [showTranslit, setShowTranslit] = useState(true);
  const [showEnglish, setShowEnglish] = useState(true);
  const [source, setSource] = useState("lxx");
  const [q, setQ] = useState("");

  const samples = ANCIENT_TEXTS[source].sample;

  const filtered = useMemo(() => {
    if (!q.trim()) return samples;
    const s = q.toLowerCase();
    return samples.filter(
      v =>
        v.ref.toLowerCase().includes(s) ||
        (showGreek && v.greek.toLowerCase().includes(s)) ||
        (showTranslit && v.translit.toLowerCase().includes(s)) ||
        (showEnglish && v.english.toLowerCase().includes(s))
    );
  }, [samples, q, showGreek, showTranslit, showEnglish]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <select className="select" value={mode} onChange={e => setMode(e.target.value)}>
          <option>Browse</option>
          <option>Search</option>
          <option>Compare</option>
        </select>
        <select className="select" value={source} onChange={e => setSource(e.target.value)}>
          <option value="lxx">Septuagint (LXX)</option>
          <option value="sinaiticus">Codex Sinaiticus</option>
        </select>
        <label className="switch"><input type="checkbox" checked={showGreek} onChange={e => setShowGreek(e.target.checked)} />Greek</label>
        <label className="switch"><input type="checkbox" checked={showTranslit} onChange={e => setShowTranslit(e.target.checked)} />Translit</label>
        <label className="switch"><input type="checkbox" checked={showEnglish} onChange={e => setShowEnglish(e.target.checked)} />English</label>
        {mode !== "Browse" && (
          <input className="input flex-1" placeholder="Search…" value={q} onChange={e => setQ(e.target.value)} />
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {filtered.map((v, i) => (
          <div key={i} className="rounded-xl border border-amber-500/20 bg-slate-800/40 p-4">
            <div className="font-semibold mb-2">{v.ref}</div>
            {showGreek && <div className="text-amber-200 mb-1">{v.greek}</div>}
            {showTranslit && <div className="text-amber-300/90 text-sm mb-1 italic">{v.translit}</div>}
            {showEnglish && <div className="text-slate-200">{v.english}</div>}
          </div>
        ))}
      </div>

      {mode === "Compare" && (
        <div className="rounded-xl border border-amber-500/20 bg-slate-800/40 p-4">
          <div className="font-semibold mb-2 flex items-center gap-2"><Compass size={16} />Comparison Note</div>
          <p className="text-slate-300">
            Use this mode to juxtapose LXX/Sinaiticus with a modern translation outside this view to observe lexical
            and syntactic variance across traditions.
          </p>
        </div>
      )}
    </div>
  );
}

/** Achievements */
function AchievementsView({ unlocked = {} }) {
  const tiers = Object.entries(ACHIEVEMENTS);
  return (
    <div className="space-y-4">
      {tiers.map(([tier, list]) => (
        <div key={tier} className="rounded-2xl border border-amber-500/20 bg-slate-800/40 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Trophy className="text-amber-300" />
            <h3 className="font-bold capitalize">{tier}</h3>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {list.map(a => {
              const isUnlocked = Boolean(unlocked[a.key]);
              return (
                <div key={a.key} className={`rounded-xl p-3 border ${isUnlocked ? "border-emerald-500/40 bg-emerald-900/20" : "border-slate-600/40 bg-slate-700/20"}`}>
                  <div className="text-lg">{a.icon} {a.name}</div>
                  <div className="text-slate-300 text-sm">{a.desc}</div>
                  <div className="mt-1 text-xs">{isUnlocked ? "Unlocked" : "Locked"}</div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

/** Enhanced Review (drag & drop) */
function EnhancedReviewView({ mode, target, onComplete }) {
  // mode: "words" (fill blanks) or "reference"
  // target: { text, tokens, missingIndices } for words OR { ref, pieces } for reference
  const [slots, setSlots] = useState(
    mode === "words"
      ? target.missingIndices.map(() => null)
      : target.pieces.map(() => null)
  );
  const bank = mode === "words" ? target.bank : target.bank; // shared

  function handleDrop(slotIdx, token) {
    setSlots(prev => {
      if (prev.includes(token)) return prev; // already used
      const next = [...prev];
      next[slotIdx] = token;
      return next;
    });
  }

  const allFilled = slots.every(Boolean);
  const allCorrect = allFilled && slots.every((t, i) => t === (mode === "words" ? target.answerTokens[i] : target.answerPieces[i]));

  useEffect(() => {
    if (allCorrect) {
      const bonus = mode === "words" ? 50 : 2;
      onComplete?.(bonus);
    }
  }, [allCorrect, mode, onComplete]);

  return (
    <div className="space-y-3">
      <div className="text-sm text-slate-300">
        Drag tokens to reconstruct the {mode === "words" ? "verse segment" : "reference"}.
      </div>
      <div className="flex flex-wrap gap-2">
        {slots.map((t, i) => (
          <div
            key={i}
            className={`min-w-[80px] px-3 py-2 rounded-xl border bg-slate-800/60 ${t ? "border-emerald-500/40" : "border-amber-500/30"}`}
          >
            {t ?? "—"}
          </div>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        {bank.map((t, i) => (
          <button
            key={i}
            disabled={slots.includes(t)}
            className={`px-3 py-2 rounded-xl border ${slots.includes(t) ? "opacity-50 cursor-not-allowed" : "hover:bg-slate-700"} border-slate-600/40`}
            onClick={() => {
              const idx = slots.findIndex(s => !s);
              if (idx !== -1) handleDrop(idx, t);
            }}
          >
            {t}
          </button>
        ))}
      </div>
      <div className="flex gap-2">
        <button className="btn" onClick={() => setSlots(slots.map(() => null))}>Reset</button>
        {allCorrect && <div className="text-emerald-400 flex items-center gap-2"><CheckCircle2 /> Perfect! Bonus applied.</div>}
      </div>
    </div>
  );
}

/** Mastery */
function MasteryView({ userData, grouping = "difficulty" }) {
  const items = userData?.verseStats || {}; // { ref: { reps, correct, byType: {fill-blank: {reps, correct}, ...}, meta: {difficulty, topic, book}} }

  const groups = useMemo(() => {
    const g = {};
    for (const [ref, s] of Object.entries(items)) {
      const key =
        grouping === "topic" ? (s.meta?.topic || "—") :
        grouping === "book" ? (s.meta?.book || "—") :
        (s.meta?.difficulty || "—");
      if (!g[key]) g[key] = [];
      g[key].push({ ref, ...s });
    }
    return g;
  }, [items, grouping]);

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        {CATEGORY_CONFIG.groupings.map(k => (
          <a key={k} href={`#${k}`} className={`chip ${grouping === k ? "chip-active" : ""}`}>{k}</a>
        ))}
      </div>
      {Object.entries(groups).map(([k, list]) => {
        const totalReps = list.reduce((a, b) => a + (b.reps || 0), 0);
        const totalCorrect = list.reduce((a, b) => a + (b.correct || 0), 0);
        const acc = totalReps ? totalCorrect / totalReps : 0;
        const lvl = masteryFromStats({ accuracy: acc, reps: totalReps });
        return (
          <details key={k} className="rounded-2xl border border-amber-500/20 bg-slate-800/40 p-4" open>
            <summary className="flex items-center gap-2 cursor-pointer">
              <BookMarked className="text-amber-300" />
              <span className="font-semibold">{k}</span>
              <span className="ml-auto text-sm">{lvl} · {(acc * 100).toFixed(0)}% · {totalReps} reps</span>
            </summary>
            <div className="mt-3 space-y-2">
              {list.map(row => {
                const accV = row.reps ? (row.correct / row.reps) : 0;
                return (
                  <div key={row.ref} className="rounded-xl border border-slate-600/40 p-3">
                    <div className="font-semibold">{row.ref}</div>
                    <div className="text-xs text-slate-300 mb-2">{row.meta?.topic} · {row.meta?.difficulty} · {row.meta?.book}</div>
                    <div className="h-2 rounded bg-slate-700 overflow-hidden">
                      <div className="h-full bg-emerald-500" style={{ width: `${accV * 100}%` }} />
                    </div>
                    <div className="text-xs mt-1">Accuracy {(accV * 100).toFixed(0)}% · {row.reps} attempts</div>
                    <div className="grid sm:grid-cols-3 gap-2 mt-2 text-xs">
                      {Object.entries(row.byType || {}).map(([type, s]) => {
                        const a = s.reps ? (s.correct / s.reps) : 0;
                        return (
                          <div key={type} className="rounded-lg border border-slate-600/40 p-2">
                            <div className="font-semibold">{type}</div>
                            <div>{(a * 100).toFixed(0)}% · {s.reps} reps</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </details>
        );
      })}
    </div>
  );
}

/** Settings */
function SettingsView({
  userData, setUserData, onOpenSharpHistory, onUnlockAncientStudy
}) {
  const translations = ["KJV", "NKJV", "NIV", "NLT", "YLT", "WEB", "ASV", "ESV", "NASB"];

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-amber-500/20 bg-slate-800/40 p-4">
        <div className="flex items-center gap-2 mb-2"><SettingsIcon className="text-amber-300" /><h3 className="font-semibold">Preferences</h3></div>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className="label">Difficulty</label>
            <select
              className="select w-full"
              value={userData.selectedDifficulty}
              onChange={e =>
                setUserData(u => ({ ...u, selectedDifficulty: e.target.value }))
              }
            >
              {CATEGORY_CONFIG.difficulties.map(d => <option key={d}>{d}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Translation</label>
            <select
              className="select w-full"
              value={userData.translation}
              onChange={e => setUserData(u => ({ ...u, translation: e.target.value }))}
            >
              {translations.map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div className="col-span-full">
            <label className="switch">
              <input
                type="checkbox"
                checked={userData.includeApocrypha}
                onChange={e => setUserData(u => ({ ...u, includeApocrypha: e.target.checked }))}
              />
              Include Apocrypha
            </label>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-amber-500/20 bg-slate-800/40 p-4">
        <div className="flex items-center gap-2 mb-2"><BookOpen className="text-amber-300" /><h3 className="font-semibold">Ancient Study</h3></div>
        <p className="text-slate-300 mb-2">
          Unlocks at <b>Advanced</b> difficulty (or via achievements). Explore LXX &amp; Codex Sinaiticus.
        </p>
        <button className="btn" onClick={onUnlockAncientStudy}>Open Ancient Study</button>
      </div>

      <div className="rounded-2xl border border-amber-500/20 bg-slate-800/40 p-4">
        <div className="flex items-center gap-2 mb-2"><BrainCircuit className="text-amber-300" /><h3 className="font-semibold">S.H.A.R.P. Conversations</h3></div>
        <button className="btn" onClick={onOpenSharpHistory}>Open Saved Sessions</button>
      </div>

      <div className="rounded-2xl border border-amber-500/20 bg-slate-800/40 p-4">
        <div className="flex items-center gap-2 mb-2"><Shield className="text-amber-300" /><h3 className="font-semibold">S.H.A.R.P. Creed of the Way</h3></div>
        <details className="rounded-lg border border-slate-600/40 p-3">
          <summary className="cursor-pointer">View / Copy</summary>
          <pre className="whitespace-pre-wrap text-sm text-slate-200 mt-2">
{`[Creed of the Way — abridged print view]
1) Scripture-centered discipleship...
2) Walk in the statutes...
3) Christ as Lord and Redeemer...
… (full creed text here as in your legacy file)`}
          </pre>
          <div className="mt-2 flex gap-2">
            <button
              className="btn"
              onClick={() => navigator.clipboard.writeText("[Creed] …")}
            >
              Copy
            </button>
            <a className="btn" href="https://www.paypal.me/" target="_blank" rel="noreferrer">Donate</a>
          </div>
        </details>
      </div>

      <div className="text-xs opacity-70">Sword Drill v{APP_VERSION}</div>
    </div>
  );
}

/** Home / Dashboard */
function HomeView({
  userData, verseOfDay, devotionalRead, onMarkDevotional,
  onStartQuiz, onOpenAnalytics
}) {
  return (
    <div className="space-y-4">
      {/* SharpAssistant / Analytics Card */}
      <div className="rounded-2xl border border-amber-500/20 bg-slate-800/40 p-4">
        <div className="flex items-center gap-2 mb-2"><BrainCircuit className="text-amber-300" /><h3 className="font-semibold">S.H.A.R.P. Assistant</h3></div>
        <SharpAssistant
          userData={userData}
          currentQuizStats={userData.quizHistory}
          verseHistory={Object.keys(userData.verseStats || {})}
          todaysQuizzesCount={userData.quizzesCompleted || 0}
          userId="demo-user"
          onOpenAnalytics={onOpenAnalytics}
        />
        <div className="mt-3">
          <button className="btn" onClick={onOpenAnalytics}>Open Analytics</button>
        </div>
      </div>

      {/* Difficulty + Progress */}
      <div className="grid md:grid-cols-3 gap-4">
        <div className="rounded-2xl border border-amber-500/20 bg-slate-800/40 p-4">
          <div className="text-sm text-slate-300">Difficulty</div>
          <div className="text-xl font-bold">{userData.selectedDifficulty}</div>
          <div className="mt-2 text-sm text-slate-400">Mastered: {userData.masteredCount || 0}</div>
        </div>

        {/* Daily Motivation */}
        <div className="rounded-2xl border border-amber-500/20 bg-slate-800/40 p-4">
          <div className="flex items-center gap-2 mb-1"><BookOpen className="text-amber-300" /><h3 className="font-semibold">Daily Motivation</h3></div>
          <div className="text-slate-200 font-semibold">{verseOfDay?.reference}</div>
          <div className="text-slate-300 text-sm">{verseOfDay?.text}</div>
          <label className="switch mt-2">
            <input type="checkbox" checked={devotionalRead} onChange={onMarkDevotional} />
            Mark as read (achievement)
          </label>
        </div>

        {/* Quick Stats */}
        <div className="rounded-2xl border border-amber-500/20 bg-slate-800/40 p-4">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <div className="text-slate-300">Streak</div>
              <StreakDisplay streak={userData.streak || 0} />
            </div>
            <div>
              <div className="text-slate-300">Quizzes</div>
              <div className="text-xl font-bold">{userData.quizzesCompleted || 0}</div>
            </div>
            <div>
              <div className="text-slate-300">Points</div>
              <div className="text-xl font-bold">{userData.points || 0}</div>
            </div>
            <div>
              <div className="text-slate-300">Mastered</div>
              <div className="text-xl font-bold">{userData.masteredCount || 0}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Start Quiz */}
      <div className="rounded-2xl border border-amber-500/20 bg-slate-800/40 p-4">
        <div className="flex items-center gap-2 mb-2"><Target className="text-amber-300" /><h3 className="font-semibold">Start a Quiz</h3></div>
        <div className="grid sm:grid-cols-3 gap-3">
          <button className="btn" onClick={() => onStartQuiz("fill-blank")}>Fill-in-the-Blank (+{QUIZ_POINTS["fill-blank"]})</button>
          <button className="btn" onClick={() => onStartQuiz("multiple-choice")}>Multiple Choice (+{QUIZ_POINTS["multiple-choice"]})</button>
          <button className="btn" onClick={() => onStartQuiz("reference-recall")}>Reference Recall (+{QUIZ_POINTS["reference-recall"]})</button>
        </div>
      </div>
    </div>
  );
}

/** Quiz View */
function QuizView({ quiz, onSubmit, onCancel }) {
  const [answer, setAnswer] = useState("");
  const [selected, setSelected] = useState(null);

  if (!quiz) return null;

  const canSubmit =
    quiz.type === "multiple-choice" ? selected !== null :
    quiz.type === "fill-blank" ? Boolean(answer.trim()) :
    quiz.type === "reference-recall" ? Boolean(answer.trim()) : false;

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-amber-500/20 bg-slate-800/40 p-4">
        <div className="flex items-center gap-2"><Target className="text-amber-300" /><h3 className="font-semibold">Quiz · {quiz.type}</h3></div>
        <div className="mt-3">
          {quiz.type === "fill-blank" && (
            <>
              <div className="text-slate-200 mb-2">{quiz.prompt}</div>
              <input
                className="input w-full"
                placeholder="Type the missing words…"
                value={answer}
                onChange={e => setAnswer(e.target.value)}
              />
            </>
          )}

          {quiz.type === "multiple-choice" && (
            <>
              <div className="text-slate-200 mb-2">{quiz.prompt}</div>
              <div className="grid sm:grid-cols-2 gap-2">
                {quiz.options.map((opt, idx) => (
                  <button
                    key={idx}
                    className={`px-3 py-2 rounded-xl border ${selected === idx ? "border-emerald-500/60 bg-emerald-900/20" : "border-slate-600/40 hover:bg-slate-700/40"}`}
                    onClick={() => setSelected(idx)}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </>
          )}

          {quiz.type === "reference-recall" && (
            <>
              <div className="text-slate-200 mb-2">{quiz.prompt}</div>
              <input
                className="input w-full"
                placeholder="Ex: John 3:16"
                value={answer}
                onChange={e => setAnswer(e.target.value)}
              />
            </>
          )}
        </div>
        <div className="mt-3 flex gap-2">
          <button className="btn" disabled={!canSubmit} onClick={() => onSubmit({ answer, selected })}>Submit</button>
          <button className="btn-secondary" onClick={onCancel}>Cancel</button>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// 4) MAIN APP (SwordDrillApp)
// ---------------------------------------------------------------------------

export default function SwordDrillApp() {
  // Navigation / view state
  const [currentView, setCurrentView] = useState("home"); // home | quiz | stats | achievements | ancient-study | help | settings
  const [menuOpen, setMenuOpen] = useState(false);

  // Auth state
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [authForm, setAuthForm] = useState({ isSignUp: false, email: "", password: "", name: "" });
  const [authError, setAuthError] = useState("");

  // Data state
  const defaultUserData = useMemo(() => ({
    name: "",
    translation: "KJV",
    includeApocrypha: false,
    selectedDifficulty: "Beginner",
    points: 0,
    streak: 0,
    lastActiveISO: null,
    quizzesCompleted: 0,
    achievements: {},
    verseProgress: {}, // ref -> { interval, nextReview }
    verseStats: {},    // ref -> { reps, correct, byType, meta }
    masteredCount: 0,
    quizHistory: [],   // Array of completed quizzes for analytics
  }), []);

  const [userData, setUserData] = useState(defaultUserData);

  // Verse of Day & flags
  const [verseOfDay, setVerseOfDay] = useState(null);
  const [devotionalRead, setDevotionalRead] = useState(false);

  // Quiz state
  const [quiz, setQuiz] = useState(null);
  const [enhancedReview, setEnhancedReview] = useState(null); // { mode, target }
  const [showAnalytics, setShowAnalytics] = useState(false);

  // Memoize quizHistory to prevent unnecessary re-renders in AnalyticsModal
  const memoizedQuizHistory = useMemo(() => userData.quizHistory || [], [userData.quizHistory]);

  // Effects: Auth init & user sync
  useEffect(() => {
    const unsub = onAuthChange(async (user) => {
      if (user) {
        setIsLoggedIn(true);
        setCurrentUser(user);
        // load user data
        const remoteResult = await getUserData(user.uid);
        const remote = remoteResult?.success ? { ...remoteResult.user, ...remoteResult.progress } : null;
        const local = JSON.parse(localStorage.getItem("sd_userData") || "null");
        const merged = { ...defaultUserData, ...(remote || {}), ...(local || {}) };
        setUserData(merged);
        // subscribe to remote updates
        const unsubProg = subscribeToUserProgress(user.uid, (result) => {
          if (result?.success && result.progress) {
            setUserData(u => ({ ...u, ...result.progress }));
          }
        });
        // initialize verse of day
        initializeDaily(merged);
        return () => unsubProg?.();
      } else {
        setIsLoggedIn(false);
        setCurrentUser(null);
        setUserData(defaultUserData);
      }
    });
    return () => unsub?.();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function persistUser(next) {
    setUserData(next);
    localStorage.setItem("sd_userData", JSON.stringify(next));
    if (currentUser) updateUserProgress(currentUser.uid, next);
  }

  async function initializeDaily(u) {
    // Use the daily verse function
    const dailyV = getDailyVerse();
    setVerseOfDay(dailyV);

    const today = todayISO();
    const devKey = `sd_devotional_${today}`;
    setDevotionalRead(localStorage.getItem(devKey) === "1");

    // streak update on login
    const res = calculateStreak(u.lastActiveISO, today);
    if (res.streak === "increment") {
      const next = { ...u, streak: (u.streak || 0) + 1, lastActiveISO: res.updatedDate };
      persistUser(next);
    } else if (res.streak === "reset") {
      const next = { ...u, streak: 1, lastActiveISO: res.updatedDate };
      persistUser(next);
    } else if (!u.lastActiveISO) {
      const next = { ...u, streak: 1, lastActiveISO: today };
      persistUser(next);
    }
  }

  // Auth handlers
  const handleAuth = async () => {
    setAuthError("");
    try {
      if (authForm.isSignUp) {
        const user = await fbSignUp(authForm.email, authForm.password, authForm.name);
        setCurrentUser(user);
      } else {
        const user = await fbSignIn(authForm.email, authForm.password);
        setCurrentUser(user);
      }
    } catch (e) {
      setAuthError(String(e?.message || e));
    }
  };
  const handleSignOut = async () => {
    await fbSignOut();
    setCurrentView("home");
  };

  // Daily devotional toggle
  const handleDevotionalRead = () => {
    const today = todayISO();
    const devKey = `sd_devotional_${today}`;
    const nextVal = !devotionalRead;
    setDevotionalRead(nextVal);
    localStorage.setItem(devKey, nextVal ? "1" : "0");
    if (nextVal) {
      const next = {
        ...userData,
        achievements: { ...userData.achievements, devotionalRead: true },
        points: (userData.points || 0) + 25,
      };
      persistUser(next);
    }
  };

  // Start Quiz
  async function startQuiz(type) {
    // Get verse from local storage only - no API calls
    const base =
      (await fetchVerseWithRetry({ translation: userData.translation, difficulty: userData.selectedDifficulty })) ||
      getFallbackVerse(userData);

    const ref = base.reference;
    const text = base.text;

    if (type === "fill-blank") {
      // Hide a short contiguous span
      const words = text.split(/\s+/);
      const start = Math.max(0, Math.floor(words.length * 0.2) - 1);
      const len = Math.max(2, Math.min(4, Math.floor(words.length * 0.1)));
      const hidden = words.slice(start, start + len).join(" ");
      const prompt =
        words.map((w, i) => (i >= start && i < start + len ? "____" : w)).join(" ") + ` — (${ref})`;
      setQuiz({
        type,
        ref,
        prompt,
        answer: hidden,
        meta: base,
      });
    } else if (type === "multiple-choice") {
      const distractors = [];
      while (distractors.length < 3) {
        const r = VERSE_DATABASE[Math.floor(Math.random() * VERSE_DATABASE.length)]?.ref;
        if (r && r !== ref && !distractors.includes(r)) distractors.push(r);
      }
      const options = [...distractors, ref].sort(() => Math.random() - 0.5);
      setQuiz({
        type,
        prompt: `Which reference matches: “${text.slice(0, 120)}…”`,
        answer: ref,
        options,
        meta: base,
      });
    } else {
      // reference-recall
      setQuiz({
        type: "reference-recall",
        prompt: `Type the reference for: “${text}”`,
        answer: ref,
        meta: base,
      });
    }

    setCurrentView("quiz");
  }

  // Submit Quiz
  async function submitQuiz({ answer, selected }) {
    if (!quiz) return;
    let isCorrect = false;
    let awarded = 0;

    if (quiz.type === "multiple-choice") {
      const chosen = quiz.options[selected];
      isCorrect = chosen === quiz.answer;
    } else {
      isCorrect = checkAnswerMatch(answer, quiz.answer);
    }

    if (isCorrect) {
      awarded = QUIZ_POINTS[quiz.type] || 0;
    }

    // Update stats & spaced repetition
    const ref = quiz.meta?.ref || quiz.ref;
    const prevProg = userData.verseProgress?.[ref] || { interval: 0, nextReview: todayISO() };
    const nextInterval = getNextInterval(prevProg.interval, isCorrect);
    const nextReviewISO = new Date();
    nextReviewISO.setDate(nextReviewISO.getDate() + nextInterval);

    const vs = userData.verseStats?.[ref] || {
      reps: 0,
      correct: 0,
      byType: {
        "fill-blank": { reps: 0, correct: 0 },
        "multiple-choice": { reps: 0, correct: 0 },
        "reference-recall": { reps: 0, correct: 0 },
      },
      meta: { difficulty: quiz.meta?.difficulty, topic: quiz.meta?.topic, book: quiz.meta?.book },
    };

    const nextStats = {
      ...vs,
      reps: vs.reps + 1,
      correct: vs.correct + (isCorrect ? 1 : 0),
      byType: {
        ...vs.byType,
        [quiz.type]: {
          reps: vs.byType[quiz.type].reps + 1,
          correct: vs.byType[quiz.type].correct + (isCorrect ? 1 : 0),
        },
      },
    };

    // Mastered count recompute quick (expensive sets can be memoized in modules)
    const tempStats = { ...(userData.verseStats || {}), [ref]: nextStats };
    const masteredCount = Object.values(tempStats).filter(s => masteryFromStats({
      accuracy: s.reps ? s.correct / s.reps : 0,
      reps: s.reps,
    }) === "Mastered").length;

    const nextUser = {
      ...userData,
      quizzesCompleted: (userData.quizzesCompleted || 0) + 1,
      points: (userData.points || 0) + awarded,
      verseProgress: {
        ...(userData.verseProgress || {}),
        [ref]: { interval: nextInterval, nextReview: nextReviewISO.toISOString().slice(0, 10) },
      },
      verseStats: tempStats,
      masteredCount,
    };

    // Achievements: easy examples
    if (!userData.achievements?.firstQuiz) {
      nextUser.achievements = { ...(userData.achievements || {}), firstQuiz: true };
    }
    if ((nextUser.points || 0) >= 1000 && !nextUser.achievements?.points1k) {
      nextUser.achievements = { ...nextUser.achievements, points1k: true };
    }
    if (nextUser.selectedDifficulty === "Advanced" && !nextUser.achievements?.ancientUnlocked) {
      nextUser.achievements = { ...nextUser.achievements, ancientUnlocked: true };
    }

    // Add quiz result to local quizHistory for analytics
    const quizResultForHistory = {
      type: quiz.type,
      reference: ref,
      correct: isCorrect,
      isCorrect: isCorrect,
      points: awarded,
      pointsEarned: awarded,
      difficulty: quiz.difficulty || userData.selectedDifficulty,
      verseDifficulty: quiz.difficulty || userData.selectedDifficulty,
      timestamp: Date.now(),
      ts: Date.now(),
    };

    nextUser.quizHistory = [...(nextUser.quizHistory || []), quizResultForHistory];

    persistUser(nextUser);

    // Save result to Firestore (best-effort)
    try {
      if (currentUser) {
        await addQuizResult(currentUser.uid, {
          type: quiz.type,
          ref,
          correct: isCorrect,
          awarded,
          ts: Date.now(),
        });
      }
    } catch {}

    if (!isCorrect) {
      // Build enhanced review target
      if (quiz.type === "fill-blank") {
        const bank = quiz.answer.split(/\s+/);
        setEnhancedReview({
          mode: "words",
          target: {
            bank,
            missingIndices: Array.from({ length: bank.length }, (_, i) => i),
            answerTokens: bank,
          },
        });
      } else {
        // reference reconstruction as book + chapter + verse tokens
        const pieces = quiz.answer.replace(" ", "").split(/:| /);
        const tokens = pieces;
        setEnhancedReview({
          mode: "reference",
          target: {
            bank: tokens,
            answerPieces: tokens,
            pieces: tokens.map(() => null),
          },
        });
      }
    } else {
      setEnhancedReview(null);
    }

    setCurrentView("home");
    setQuiz(null);
  }

  function onEnhancedComplete(bonus) {
    const next = { ...userData, points: (userData.points || 0) + bonus };
    persistUser(next);
    setEnhancedReview(null);
  }

  // UI helpers
  const NavButton = ({ icon, label, view }) => (
    <button
      className={`nav-btn ${currentView === view ? "nav-btn-active" : ""}`}
      onClick={() => { setCurrentView(view); setMenuOpen(false); }}
    >
      {icon}<span>{label}</span>
    </button>
  );

  // -------------------------------------------------------------------------
  // RENDER
  // -------------------------------------------------------------------------
  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-slate-900 text-slate-100">
        {/* Header */}
        <header className="sticky top-0 z-40 backdrop-blur bg-slate-900/80 border-b border-amber-500/20">
          <div className="max-w-6xl mx-auto px-4 h-14 flex items-center gap-3">
            <button className="md:hidden p-2" onClick={() => setMenuOpen(s => !s)} aria-label="Menu">
              <Menu />
            </button>
            <div className="font-extrabold tracking-wide">⚔️ Sword Drill</div>
            <div className="ml-auto flex items-center gap-3">
              {isLoggedIn && <StreakDisplay streak={userData.streak || 0} />}
              {!isLoggedIn ? (
                <button className="btn-outline flex items-center gap-2" onClick={() => setCurrentView("home")}><LogIn size={18} />Sign in</button>
              ) : (
                <button className="btn-outline flex items-center gap-2" onClick={handleSignOut}><LogOut size={18} />Sign out</button>
              )}
            </div>
          </div>
        </header>

        {/* Main */}
        <div className="max-w-6xl mx-auto px-4 py-6 grid md:grid-cols-[220px,1fr] gap-6">
          {/* Sidebar */}
          <aside className={`md:sticky md:top-16 h-max space-y-2 ${menuOpen ? "" : "hidden md:block"}`}>
            <NavButton view="home" icon={<Home size={18} />} label="Home" />
            <NavButton view="stats" icon={<BookMarked size={18} />} label="Mastery" />
            <NavButton view="achievements" icon={<Trophy size={18} />} label="Achievements" />
            <NavButton view="ancient-study" icon={<BookOpen size={18} />} label="Ancient Study" />
            <NavButton view="help" icon={<HelpCircle size={18} />} label="Help" />
            <NavButton view="settings" icon={<SettingsIcon size={18} />} label="Settings" />
          </aside>

          {/* Content */}
          <main className="space-y-6">
            {/* Auth gate */}
            {!isLoggedIn && (
              <div className="rounded-2xl border border-amber-500/20 bg-slate-800/40 p-6">
                <div className="flex items-center gap-2 mb-3">
                  <Shield className="text-amber-300" />
                  <h2 className="text-xl font-bold">{authForm.isSignUp ? "Create your account" : "Welcome back"}</h2>
                </div>
                <div className="grid sm:grid-cols-2 gap-3">
                  {authForm.isSignUp && (
                    <input className="input" placeholder="Name" value={authForm.name} onChange={e => setAuthForm(f => ({ ...f, name: e.target.value }))} />
                  )}
                  <input className="input" placeholder="Email" type="email" value={authForm.email} onChange={e => setAuthForm(f => ({ ...f, email: e.target.value }))} />
                  <input className="input" placeholder="Password" type="password" value={authForm.password} onChange={e => setAuthForm(f => ({ ...f, password: e.target.value }))} />
                </div>
                {authError && <div className="mt-2 text-rose-400 text-sm">{authError}</div>}
                <div className="mt-3 flex items-center gap-2">
                  <button className="btn" onClick={handleAuth}>{authForm.isSignUp ? "Sign up" : "Sign in"}</button>
                  <button className="btn-secondary" onClick={() => setAuthForm(f => ({ ...f, isSignUp: !f.isSignUp }))}>
                    {authForm.isSignUp ? "Have an account?" : "Create account"}
                  </button>
                </div>
              </div>
            )}

            {/* Logged-in views */}
            {isLoggedIn && currentView === "home" && (
              <HomeView
                userData={userData}
                verseOfDay={verseOfDay}
                devotionalRead={devotionalRead}
                onMarkDevotional={handleDevotionalRead}
                onStartQuiz={startQuiz}
                onOpenAnalytics={() => setShowAnalytics(true)}
              />
            )}

            {isLoggedIn && currentView === "quiz" && (
              <QuizView
                quiz={quiz}
                onSubmit={submitQuiz}
                onCancel={() => { setQuiz(null); setCurrentView("home"); }}
              />
            )}

            {isLoggedIn && currentView === "stats" && (
              <MasteryView userData={userData} grouping="difficulty" />
            )}

            {isLoggedIn && currentView === "achievements" && (
              <AchievementsView unlocked={userData.achievements} />
            )}

            {isLoggedIn && currentView === "ancient-study" && (
              <AncientStudyView />
            )}

            {isLoggedIn && currentView === "help" && (
              <HelpView />
            )}

            {isLoggedIn && currentView === "settings" && (
              <SettingsView
                userData={userData}
                setUserData={persistUser}
                onOpenSharpHistory={() => alert("Open SharpAssistant saved sessions panel")}
                onUnlockAncientStudy={() => setCurrentView("ancient-study")}
              />
            )}

            {/* Enhanced Review modal-like section */}
            {enhancedReview && (
              <div className="rounded-2xl border border-amber-500/20 bg-slate-900/80 p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="text-amber-300" />
                  <h3 className="font-semibold">Enhanced Review</h3>
                </div>
                <EnhancedReviewView
                  mode={enhancedReview.mode}
                  target={enhancedReview.target}
                  onComplete={onEnhancedComplete}
                />
              </div>
            )}
          </main>
        </div>

        {/* Analytics modal */}
        {showAnalytics && (
          <AnalyticsModal
            isOpen={showAnalytics}
            onClose={() => setShowAnalytics(false)}
            quizHistory={memoizedQuizHistory}
            userData={userData}
          />
        )}
      </div>
    </ErrorBoundary>
  );
}

// ---------------------------------------------------------------------------
// 5) Minimal styles (Tailwind utility helpers via CSS classes)
//    You already use Tailwind; these classes are just semantic aliases.
// ---------------------------------------------------------------------------
// In App.css (already imported) ensure these helpers exist or replace with your own:
//
// .btn { @apply px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white; }
// .btn-secondary { @apply px-4 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-white; }
// .btn-outline { @apply px-3 py-1.5 rounded-lg border border-slate-600/60 hover:bg-slate-700/40; }
// .nav-btn { @apply w-full px-3 py-2 rounded-lg flex items-center gap-2 text-left border border-transparent hover:border-amber-500/30; }
// .nav-btn-active { @apply border-amber-500/40 bg-slate-800/40; }
// .input { @apply px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-600/40 w-full; }
// .select { @apply px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-600/40; }
// .label { @apply block text-sm text-slate-300 mb-1; }
// .switch { @apply inline-flex items-center gap-2 text-sm; }
// .chip { @apply inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-slate-600/40 text-sm; }
// .chip-active { @apply border-amber-500/50 bg-slate-800/60; }
