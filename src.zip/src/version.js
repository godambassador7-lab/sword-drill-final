// Centralized app version
// Update alongside package.json when bumping versions
export const APP_VERSION = '0.1.0';

