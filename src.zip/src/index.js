import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';  // ⬅️ THIS LINE MUST BE HERE!
import App from './App';
// import App from './AppSimple';  // TEMPORARY: Testing with simple app
import reportWebVitals from './reportWebVitals';
import * as serviceWorkerRegistration from './serviceWorkerRegistration';

const root = ReactDOM.createRoot(document.getElementById('root'));

// Only use StrictMode in development to avoid double rendering in production
const AppWrapper = process.env.NODE_ENV === 'development'
  ? () => <React.StrictMode><App /></React.StrictMode>
  : App;

root.render(<AppWrapper />);

reportWebVitals();
// Disable service worker caching during development to avoid stale bundles
serviceWorkerRegistration.unregister();
