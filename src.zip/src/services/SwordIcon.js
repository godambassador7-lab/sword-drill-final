// SwordIcon.js
// ============================================
// Sword Emoji Icon Component
// ============================================

import React from 'react';

export const SwordIcon = ({ size = 32, className = '' }) => {
  return (
    <span
      style={{
        fontSize: size,
        display: 'inline-block',
        verticalAlign: 'middle',
        userSelect: 'none',
      }}
      className={className}
      role="img"
      aria-label="Sword"
    >
      🗡️
    </span>
  );
};

export default SwordIcon;