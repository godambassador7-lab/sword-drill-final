﻿import { buildApologeticResponse, findReligionsIn, listReligions } from './retrieval/religionsProvider';import { routeIntent } from './intentRouter';
import { parseReference } from './referenceParser';
import { searchLocalVerses, getVerseByReference } from './retrieval/bibleProvider';
import { getKJVVerses } from './retrieval/kjvProvider';
import { getWEBVerses } from './retrieval/webProvider';
import { getESVVerses } from './retrieval/esvProvider';
import { getBishopsVerses } from './retrieval/bishopsProvider';
import { getGenevaVerses } from './retrieval/genevaProvider';
import { getASVVerses } from './retrieval/asvProvider';
import { getWlcVerseByReference } from './retrieval/wlcProvider';
import { getLxxVerseByReference } from './retrieval/lxxProvider';
import { getSinaiticusVerseByReference } from './retrieval/sinaiticusProvider';
import { isApocryphaBook, getApocryphaVerses } from './retrieval/apocryphaProvider';
import { synthesizeNeutral } from './synthesizer';
import { applyNeutrality } from './neutralityGuard';
import { getCrossReferences } from './retrieval/crossRefsProvider';
import { lookupWordStudy } from './lexiconProvider';
import { lookupDefinition, searchDefinitionsPrefix, searchDefinitionsFuzzy } from './dictionaryProvider';

// Cache for verse lookups to avoid redundant fetches
const verseCache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

function getCacheKey(book, chapter, verse, verseEnd, translation) {
  return `${translation}:${book}:${chapter}:${verse}${verseEnd ? `-${verseEnd}` : ''}`;
}

function formatVersesBlock(arr) {
  return arr.map(v => `"${v.text}"\nâ€" ${v.reference} (${v.translation})`).join('\n\n');
}

function mentionsMasoretic(q) {
  const s = (q || '').toLowerCase();
  return /\b(masoretic|wlc|hebrew\s+(?:text|mt)|original\s+hebrew)\b/.test(s);
}

function mentionsLxx(q) {
  const s = (q || '').toLowerCase();
  return /\b(lxx|septuagint|old\s+greek|rahlfs)\b/.test(s);
}

function mentionsSinaiticus(q) {
  const s = (q || '').toLowerCase();
  return /\b(sinaiticus|codex\s+sinaiticus|aleph|\b01\b)\b/.test(s);
}

async function getWlcRange(parsed, options = {}) {
  const out = [];
  const start = parsed.verse || 1;
  const end = parsed.verseEnd && parsed.verseEnd >= start ? parsed.verseEnd : start;
  for (let v = start; v <= end; v++) {
    const ref = `${parsed.book} ${parsed.chapter}:${v}`;
    const one = await getWlcVerseByReference(ref, options);
    if (one) out.push(one);
  }
  return out;
}

async function fetchPreferredVerses(parsed, preferred) {
  const pref = (preferred || 'KJV').toUpperCase();

  // Check cache first
  const cacheKey = getCacheKey(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd, pref);
  const cached = verseCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data;
  }

  let arr = [];
  // Apocrypha quick path
  if (isApocryphaBook(parsed.book) && parsed.verse) {
    arr = await getApocryphaVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (arr && arr.length) {
      verseCache.set(cacheKey, { data: arr, timestamp: Date.now() });
      return arr;
    }
  }
  if (pref === 'WEB') {
    arr = await getWEBVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getKJVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getESVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getASVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
  } else if (pref === 'ESV') {
    arr = await getESVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getWEBVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getKJVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getASVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
  } else if (pref === 'ASV') {
    arr = await getASVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getWEBVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getKJVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getESVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
  } else if (pref === 'BISHOPS') {
    arr = await getBishopsVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getWEBVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getKJVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getESVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
  } else if (pref === 'GENEVA') {
    arr = await getGenevaVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getWEBVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getKJVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getESVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
  } else {
    arr = await getKJVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getWEBVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getESVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
    if (!arr || arr.length === 0) arr = await getASVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd);
  }

  // Cache the result before returning
  if (arr && arr.length > 0) {
    verseCache.set(cacheKey, { data: arr, timestamp: Date.now() });
  }

  return arr || [];
}

export async function answerQuery(userMessage, context = {}) {
  const routed = routeIntent(userMessage);
  let query = routed.query;

  const parsed = parseReference(userMessage);
  if (parsed.valid) query = parsed.normalized;

  // Word study
  if (routed.type === 'word_study') {
    const entry = lookupWordStudy(query);
    if (entry) {
      const ans = `Word Study: ${entry.lemma} (${entry.language}) â€” Strong's ${entry.strong}\nMeaning: ${entry.gloss}\nNotes: ${entry.notes}\n\nHint: Ask for passages that use this term to see usage in context.`;
      return { answer: applyNeutrality(ans), citations: [] };
    }
  }

  // Compare translations
  if (routed.type === 'compare_translations' && parsed.valid && parsed.verse) {
    // Apocrypha branch: include APOC source first when applicable
    const apoc = isApocryphaBook(parsed.book)
      ? (await getApocryphaVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd))[0]
      : null;
    const kjv = (await getKJVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd))[0];
    const web = (await getWEBVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd))[0];
    const esv = (await getESVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd))[0];
    const asv = (await getASVVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd))[0];
    const bishops = (await getBishopsVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd))[0];
    const geneva = (await getGenevaVerses(parsed.book, parsed.chapter, parsed.verse, parsed.verseEnd))[0];
    if (apoc || kjv || web || esv || asv || bishops || geneva) {
      let ans = `Compare translations for ${parsed.normalized}:`;
      if (apoc) ans += `\n\n[APOC] ${apoc.text}`;
      if (kjv) ans += `\n\n[KJV] ${kjv.text}`;
      if (web) ans += `\n\n[WEB] ${web.text}`;
      if (esv) ans += `\n\n[ESV] ${esv.text}`;
      if (asv) ans += `\n\n[ASV] ${asv.text}`;
      if (bishops) ans += `\n\n[BISHOPS] ${bishops.text}`;
      if (geneva) ans += `\n\n[GENEVA] ${geneva.text}`;
      ans += `\n\nTip: Ask "cross refs for ${parsed.normalized}" or "word study on <term>".`;
      const meta = { compare: { ref: parsed.normalized, apoc: apoc?.text || '', kjv: kjv?.text || '', web: web?.text || '', esv: esv?.text || '', asv: asv?.text || '', bishops: bishops?.text || '', geneva: geneva?.text || '' }, apoc: !!apoc };
      const transList = ['APOC','KJV','WEB','ESV','ASV','BISHOPS','GENEVA'].filter((t, i) => [apoc, kjv, web, esv, asv, bishops, geneva][i]).join('/');
      return { answer: applyNeutrality(ans), citations: [{ ref: parsed.normalized, translation: transList }], meta };
    }
  }

  // Passage context
  if (routed.type === 'context' && parsed.valid) {
    const key = parsed.normalized;
    let primary = getVerseByReference(key);
    if (!primary && parsed.verse) {
      const prefArr = await fetchPreferredVerses(parsed, context.selectedTranslation);
      if (prefArr.length) primary = prefArr[0];
    }
    let ans = `Passage context for ${key} (concise):`;
    if (primary) ans += `\n\n"${primary.text}" â€” ${key}`;
    ans += `\n\nFor full literary context, read the surrounding paragraph in your preferred translation and consider crossâ€‘references.`;
    const related = getCrossReferences(key);
    if (related.length) ans += `\nRelated passages: ${related.join(', ')}.`;
    return { answer: applyNeutrality(ans), citations: [{ ref: key, translation: primary?.translation || 'Unknown' }] };
  }

  // Masoretic (WLC) explicit requests with token metadata (early return)
  if (parsed.valid && parsed.verse && mentionsMasoretic(userMessage)) {
    const verses = await getWlcRange(parsed, { stripDiacritics: true, addRtl: true });
    if (verses.length) {
      const header = 'WLC Masoretic';
      const body = verses.map(v => `"${v.text}"\n- ${v.reference} (WLC)`).join('\n\n');
      const ansBody = `[${header}]\n${body}`;
      const related = getCrossReferences(parsed.normalized);
      const ans = related.length ? `${ansBody}\n\nRelated passages: ${related.join(', ')}.` : ansBody;
      const wlcVerses = verses.map(v => ({ ref: v.reference, words: v.words || [] }));
      return { answer: applyNeutrality(ans), citations: verses.map(v => ({ ref: v.reference, translation: 'WLC' })), meta: { wlc: true, wlcVerses } };
    }
  }

  // Septuagint (LXX) explicit requests with token metadata (early return)
  if (parsed.valid && parsed.verse && mentionsLxx(userMessage)) {
    const start = parsed.verse || 1;
    const end = parsed.verseEnd && parsed.verseEnd >= start ? parsed.verseEnd : start;
    const verses = [];
    for (let v = start; v <= end; v++) {
      const ref = `${parsed.book} ${parsed.chapter}:${v}`;
      const one = await getLxxVerseByReference(ref);
      if (one) verses.push(one);
    }
    if (verses.length) {
      const header = 'LXX Septuagint';
      const body = verses.map(v => `"${v.text}"\n- ${v.reference} (LXX)`).join('\n\n');
      const ansBody = `[${header}]\n${body}`;
      const related = getCrossReferences(parsed.normalized);
      const ans = related.length ? `${ansBody}\n\nRelated passages: ${related.join(', ')}.` : ansBody;
      const lxxVerses = verses.map(v => ({ ref: v.reference, words: v.words || [] }));
      return { answer: applyNeutrality(ans), citations: verses.map(v => ({ ref: v.reference, translation: 'LXX' })), meta: { lxx: true, lxxVerses } };
    }
  }

  // Codex Sinaiticus explicit requests
  if (parsed.valid && parsed.verse && mentionsSinaiticus(userMessage)) {
    const start = parsed.verse || 1;
    const end = parsed.verseEnd && parsed.verseEnd >= start ? parsed.verseEnd : start;
    const verses = [];
    for (let v = start; v <= end; v++) {
      const ref = `${parsed.book} ${parsed.chapter}:${v}`;
      const one = await getSinaiticusVerseByReference(ref);
      if (one) verses.push(one);
    }
    if (verses.length) {
      const header = 'Codex Sinaiticus';
      const body = verses.map(v => `"${v.text}"\n- ${v.reference} (SINAITICUS)`).join('\n\n');
      const ansBody = `[${header}]\n${body}`;
      const related = getCrossReferences(parsed.normalized);
      const ans = related.length ? `${ansBody}\n\nRelated passages: ${related.join(', ')}.` : ansBody;
      const sinaiticusVerses = verses.map(v => ({ ref: v.reference, words: v.words || [] }));
      return { answer: applyNeutrality(ans), citations: verses.map(v => ({ ref: v.reference, translation: 'SINAITICUS' })), meta: { sinaiticus: true, sinaiticusVerses } };
    }
    // Fallback: not extant at requested verse in Sinaiticus; try LXX then preferred translations
    const lxx = [];
    for (let v = start; v <= end; v++) {
      const ref = `${parsed.book} ${parsed.chapter}:${v}`;
      const one = await getLxxVerseByReference(ref);
      if (one) lxx.push(one);
    }
    if (lxx.length) {
      const note = 'Note: requested verse is not extant in Codex Sinaiticus; showing Septuagint (LXX).';
      const body = lxx.map(v => `"${v.text}"\n- ${v.reference} (LXX)`).join('\n\n');
      const ansBody = `${note}\n\n${body}`;
      const related = getCrossReferences(parsed.normalized);
      const ans = related.length ? `${ansBody}\n\nRelated passages: ${related.join(', ')}.` : ansBody;
      const lxxVerses = lxx.map(v => ({ ref: v.reference, words: v.words || [] }));
      return { answer: applyNeutrality(ans), citations: lxx.map(v => ({ ref: v.reference, translation: 'LXX' })), meta: { lxx: true, lxxVerses, sinaiticusMissing: true } };
    }
    // Final fallback: preferred/KJV
    const prefArr = await fetchPreferredVerses(parsed, context.selectedTranslation);
    if (prefArr.length) {
      let ans = `Note: requested verse is not extant in Codex Sinaiticus; showing ${prefArr[0].translation}.`;
      ans += `\n\n${formatVersesBlock(prefArr)}`;
      const related = getCrossReferences(parsed.normalized);
      if (related.length) ans += `\n\nRelated passages: ${related.join(', ')}.`;
      return { answer: applyNeutrality(ans), citations: prefArr.map(v => ({ ref: v.reference, translation: v.translation })), meta: { sinaiticusMissing: true } };
    }
  }

  // Direct reference
  if (routed.type === 'reference' && parsed.valid && parsed.verse) {
    const arr = await fetchPreferredVerses(parsed, context.selectedTranslation);
    if (arr.length) {
      let ans = formatVersesBlock(arr);
      const related = getCrossReferences(parsed.normalized);
      if (related.length) ans += `\n\nRelated passages: ${related.join(', ')}.`;
      const hasApoc = arr.some(v => v.translation === 'APOC');
      return { answer: applyNeutrality(ans), citations: arr.map(v => ({ ref: v.reference, translation: v.translation })), meta: hasApoc ? { apoc: true } : undefined };
    }
  }

  // Retrieval + synthesis fallback
  const hits = await searchLocalVerses(query, { verseHistory: context.verseHistory, selectedTranslation: context.selectedTranslation });
  let { answer, citations } = synthesizeNeutral({ query, hits });

  if (routed.type === 'theology') {
    // Lightly elevate the register for theological/philosophical prompts
    if (answer.includes('How to read these neutrally:')) {
      answer = answer.replace('How to read these neutrally:', 'Hermeneutical advisories:');
    } else {
      answer += '\n\nHermeneutical advisories:';
    }
    answer += '\nâ€¢ Situate the pericope within its literary horizon.';
    answer += '\nâ€¢ Compare renderings across traditions (translation families).';
    answer += '\nâ€¢ Correlate with canonical cross-references (Scripture interpreting Scripture).';

    // Append one advanced term definition if available
    const terms = (userMessage || '').split(/[^A-Za-z]+/).filter(w => w && w.length > 6);
    for (const t of terms.slice(0, 3)) {
      // eslint-disable-next-line no-await-in-loop
      const def = await lookupDefinition(t);
      if (def) {
        const head = def.headword || t;
        const pos = def.pos ? ` (${def.pos})` : '';
        const gloss = def.def || def.definition || '';
        answer += `\n\nTerminology â€” ${head}${pos}: ${gloss}`;
        break;
      }
    }
  }
  const primaryRef = hits[0]?.reference || (parseReference(query).normalized);
  if (primaryRef) {
    const related = getCrossReferences(primaryRef);
    if (related.length) answer += `\n\nRelated passages: ${related.join(', ')}.`;
  }
  return { answer: applyNeutrality(answer), citations };
}

export default { answerQuery };