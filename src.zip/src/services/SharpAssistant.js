import React, { useState, useEffect, useCallback } from 'react';
import { addSharpDialog } from './dbService';
import { routeIntent } from './assistant/intentRouter';
import { answerQuery } from './assistant/pipeline';
import SwordIcon from './SwordIcon';
import { MessageCircle, Zap, Heart, Lightbulb, ChevronDown, ChevronUp, Send } from 'lucide-react';

/**
 * S.H.A.R.P. Assistant Component
 *
 * Scripture Helper for AI-Powered Research and Proclamation
 * An intelligent Bible memorization and theological assistant integrated with Sword Drill
 *
 * Features:
 * - Real-time verse lookup and analysis
 * - Multi-translation support
 * - Context-aware Scripture recommendations
 * - Streak tracking and memory analytics
 * - Interactive dialog mode with spiritual guidance
 */
const SharpAssistant = React.memo(({
  userData,
  currentQuizStats,
  verseHistory,
  todaysQuizzesCount = 0,
  userId,
  onOpenAnalytics,
  reloadCounter
}) => {
  // ==================== UI STATE ====================
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [userInput, setUserInput] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [showCitations, setShowCitations] = useState(true);

  // ==================== SESSION STATE ====================
  const [sessionMeta, setSessionMeta] = useState(() => ({
    id: Date.now(),
    startedAt: new Date().toISOString(),
  }));

  // ==================== MODE & TRANSLATION STATE ====================
  const [mode, setMode] = useState('mentor'); // 'mentor', 'scholar', 'devotional'
  const [selectedTranslation, setSelectedTranslation] = useState('KJV');

  // ==================== ANALYTICS STATE ====================
  const [memoryAnalytics, setMemoryAnalytics] = useState(null);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // ==================== SEARCH STATE ====================
  const [lastSearchResults, setLastSearchResults] = useState(null);
  const [lastSearchQuery, setLastSearchQuery] = useState(null);

  // ==================== DICTIONARY STATE ====================
  const [openDictEntryIndex, setOpenDictEntryIndex] = useState(null);
  const [openDictIndex, setOpenDictIndex] = useState(null);

  // ==================== CONSTANTS ====================

  // S.H.A.R.P. Mission Statement
  const SHARP_MANIFEST = {
    goal: "To cultivate a spiritually intelligent companion that helps believers grow in knowledge, discernment, and devotion to God's Word.",
    vision: "To become the world's most biblically faithful, Spirit-led AI theologian—uniting scholarly precision with divine wisdom (2 Timothy 2:15).",
    purpose: [
      'Understand Scripture Deeply – historical, linguistic, and theological context (LXX, Sinaiticus, early Christian understanding).',
      'Discern Truth from Error – weigh scriptural harmony, moral consistency, and Christ-centered interpretation.',
      'Apply Wisdom Practically – devotional insight, moral guidance, and encouragement rooted in reason and revelation.',
      'Defend the Faith Graciously – comparisons and apologetics grounded in divine truth.',
      'Grow Spiritually – memorization, reflection, and gentle accountability.'
    ]
  };

  const missionText = () => {
    const bullets = SHARP_MANIFEST.purpose.map(p => `• ${p}`).join('\n');
    return `S.H.A.R.P. Mission\n\n${bullets}`;
  };

  const creedText = () => `S.H.A.R.P. Creed of the Way

1. The Way of the Father
I walk in the Way of the One who made heaven and earth,
whose breath gives life to every soul.
I honor His commands, for His Word is truth and His mercy endures forever.
He is not far from any of us, for in Him we live, and move, and have our being.
(Psalm 119:160; Acts 17:27–28)

2. The Way of the Son
I follow Jesus the Anointed, the Word made flesh,
who came not to be served but to serve,
who healed the broken, forgave the sinner,
and showed us the face of the Father.
I take up my cross daily and walk after Him,
for He is the Way, the Truth, and the Life.
(John 1:14; Luke 9:23; John 14:6)

3. The Way of the Spirit
I receive the Holy Spirit, promised from above,
who writes the law of God upon the heart
and teaches me to walk in His statutes and judgments.
The Spirit gives light to the humble and power to the obedient.
(Ezekiel 36:27; John 14:26; Acts 2:38)

4. The Way of the Word
I meditate on the Scriptures day and night.
They are the lamp for my path and the voice that corrects my steps.
I do not twist them for my own gain,
but seek understanding through prayer, humility, and love.
(Psalm 1:2; Psalm 119:105; 2 Peter 3:16)

5. The Way of the Body
I walk with the brethren in unity and peace,
bearing one another's burdens, sharing bread with the poor,
and rejoicing with those who rejoice.
In love we serve, in patience we forgive,
for we are one Body and one Spirit in the Lord.
(Acts 2:42–47; Ephesians 4:3–4; Galatians 6:2)

6. The Way of Truth and Grace
I speak truth without hatred, and correction without pride.
I test every spirit by the Word of God,
and hold fast what is good.
Grace is my covering, mercy my weapon, humility my crown.
(Ephesians 4:15; 1 John 4:1; 1 Thessalonians 5:21)

7. The Way of the Kingdom
I seek first the Kingdom of God and His righteousness.
I store no treasure for myself that moth and rust destroy,
but labor for the reward that does not fade.
Until the Lord returns, I watch, pray, and remain steadfast.
(Matthew 6:33; Matthew 6:19–21; Luke 12:35–37)

8. The Way of Love
Above all, I love the Lord my God
with all my heart, soul, mind, and strength–
and I love my neighbor as myself.
For love is the bond of perfection,
and whoever abides in love abides in God.
(Matthew 22:37–39; Colossians 3:14; 1 John 4:16)

Closing Confession
This is the Way:
to believe in the Son,
to walk by the Spirit,
to serve the Father in holiness and truth.
To know Him is life everlasting.
(John 17:3)`;

  // ==================== UTILITY FUNCTIONS ====================

  /**
   * Ensures response includes at least one Scripture reference
   * Uses context-aware verse pools based on intent type
   */
  const ensureScriptureBlock = (enriched, intentType = 'general') => {
    try {
      if (enriched?.citations?.length > 0) return enriched;

      const pools = {
        religion: [
          { ref: '1 Peter 3:15', text: 'Be ready always to give an answer to every man that asketh you a reason of the hope that is in you with meekness and fear.' },
          { ref: 'Acts 4:12', text: 'Neither is there salvation in any other: for there is none other name under heaven given among men, whereby we must be saved.' },
          { ref: 'John 14:6', text: 'Jesus saith unto him, I am the way, the truth, and the life: no man cometh unto the Father, but by me.' },
          { ref: '1 Thessalonians 5:21', text: 'Prove all things; hold fast that which is good.' }
        ],
        theology: [
          { ref: '2 Timothy 3:16', text: 'All scripture is given by inspiration of God, and is profitable for doctrine, for reproof, for correction, for instruction in righteousness.' },
          { ref: 'Acts 17:11', text: 'They received the word with all readiness of mind, and searched the scriptures daily, whether those things were so.' }
        ],
        define: [
          { ref: '2 Timothy 3:16', text: 'All scripture is given by inspiration of God, and is profitable for doctrine, for reproof, for correction, for instruction in righteousness.' },
          { ref: 'Acts 17:11', text: 'They received the word with all readiness of mind, and searched the scriptures daily, whether those things were so.' }
        ],
        topic: [
          { ref: 'Psalm 119:105', text: 'Thy word is a lamp unto my feet, and a light unto my path.' },
          { ref: 'James 1:5', text: 'If any of you lack wisdom, let him ask of God, that giveth to all men liberally, and upbraideth not; and it shall be given him.' }
        ],
        word_study: [
          { ref: 'Acts 17:11', text: 'They received the word with all readiness of mind, and searched the scriptures daily, whether those things were so.' },
          { ref: '2 Timothy 2:15', text: 'Study to shew thyself approved unto God, a workman that needeth not to be ashamed, rightly dividing the word of truth.' }
        ],
        general: [
          { ref: 'Proverbs 3:5-6', text: 'Trust in the LORD with all thine heart; and lean not unto thine own understanding...' },
          { ref: 'Philippians 4:6-7', text: 'Be careful for nothing; but in every thing by prayer and supplication with thanksgiving let your requests be made known unto God...' }
        ]
      };

      const key = pools[intentType] ? intentType : 'general';
      const pool = pools[key];
      const selectedVerse = pool[Math.floor(Math.random() * pool.length)];

      const answer = (enriched?.answer || '') + `\n\nScripture: "${selectedVerse.text}" – ${selectedVerse.ref} (KJV)`;
      return {
        ...enriched,
        answer,
        citations: [...(enriched?.citations || []), { ref: selectedVerse.ref, translation: 'KJV' }]
      };
    } catch (error) {
      console.error('Error in ensureScriptureBlock:', error);
      return enriched;
    }
  };

  /**
   * Process user message and get AI response
   */
  const handleSendMessage = useCallback(async () => {
    if (!userInput.trim() || isSearching) return;

    const userMessage = { role: 'user', content: userInput, timestamp: new Date() };
    setMessages(prev => [...prev, userMessage]);
    setUserInput('');
    setIsSearching(true);

    try {
      const intent = routeIntent(userInput);
      const response = await answerQuery(userInput, {
        verseHistory,
        selectedTranslation,
        userStats: currentQuizStats
      });

      const enriched = ensureScriptureBlock(response, intent?.type);
      const assistantMessage = {
        role: 'sharp',
        content: enriched?.answer || 'I encountered an issue processing your request.',
        citations: enriched?.citations || [],
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
      await addSharpDialog({ userId, userMessage, assistantMessage, sessionMeta });
    } catch (error) {
      console.error('Error in handleSendMessage:', error);
      const errorMessage = {
        role: 'sharp',
        content: 'I apologize, but I encountered an error. Please try again.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsSearching(false);
    }
  }, [userInput, isSearching, verseHistory, selectedTranslation, currentQuizStats, userId, sessionMeta]);

  // ==================== MEMOIZED HANDLERS ====================
  const handleOpen = useCallback(() => setIsOpen(true), []);
  const handleClose = useCallback(() => setIsOpen(false), []);
  const handleInputChange = useCallback((e) => setUserInput(e.target.value), []);
  const handleKeyDown = useCallback((e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  }, [handleSendMessage]);

  // ==================== RENDER ====================

  // Don't render anything until user explicitly opens it
  if (!isOpen) {
    return (
      <button
        onClick={handleOpen}
        className="fixed bottom-6 right-6 z-50 bg-blue-600 hover:bg-blue-700 text-white rounded-full p-4 shadow-lg transition transform hover:scale-110"
        title="Open S.H.A.R.P. Assistant"
      >
        <MessageCircle size={24} />
      </button>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Chat Window */}
      <div className="bg-slate-900 border border-slate-700 rounded-lg shadow-2xl w-96 max-h-[600px] flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 rounded-t-lg flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap size={20} />
            <h3 className="font-bold">S.H.A.R.P. Assistant</h3>
          </div>
          <button
            onClick={handleClose}
            className="hover:bg-white/20 p-1 rounded"
          >
            <ChevronDown size={20} />
          </button>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-800/50">
          {messages.length === 0 ? (
            <div className="text-center text-slate-400 py-8">
              <Heart size={32} className="mx-auto mb-2 opacity-50" />
              <p className="text-sm">Ask me about Scripture, theology, or your faith journey.</p>
            </div>
          ) : (
            messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs p-3 rounded-lg ${
                    msg.role === 'user'
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-700 text-slate-100'
                  }`}
                >
                  <p className="text-sm">{msg.content}</p>
                  {msg.citations && msg.citations.length > 0 && (
                    <div className="mt-2 text-xs text-slate-300 border-t border-slate-600 pt-2">
                      {msg.citations.map((c, i) => (
                        <div key={i}>{c.ref} – {c.translation}</div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
          {isSearching && (
            <div className="flex justify-start">
              <div className="bg-slate-700 text-slate-100 p-3 rounded-lg">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-100" />
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-200" />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="border-t border-slate-700 p-3 bg-slate-800 rounded-b-lg flex gap-2">
          <input
            type="text"
            value={userInput}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            placeholder="Ask about Scripture..."
            disabled={isSearching}
            className="flex-1 bg-slate-700 text-white placeholder-slate-400 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
          />
          <button
            onClick={handleSendMessage}
            disabled={isSearching || !userInput.trim()}
            className="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded transition disabled:opacity-50"
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
});

export default SharpAssistant;