import { doc, getDoc, updateDoc, setDoc, arrayUnion, onSnapshot } from 'firebase/firestore';
import { db } from './firebase';

export const getUserData = async (userId) => {
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    const progressDoc = await getDoc(doc(db, 'userProgress', userId));
    
    return {
      success: true,
      user: userDoc.data(),
      progress: progressDoc.data()
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// ✅ NEW: Real-time listener for userProgress changes
export const subscribeToUserProgress = (userId, callback) => {
  try {
    const unsubscribe = onSnapshot(doc(db, 'userProgress', userId), (doc) => {
      if (doc.exists()) {
        console.log("📡 Real-time update from Firebase:", doc.data());
        callback({
          success: true,
          progress: doc.data()
        });
      }
    }, (error) => {
      console.error("❌ Error subscribing to progress:", error);
      callback({ success: false, error: error.message });
    });
    
    return unsubscribe; // Return function to unsubscribe later
  } catch (error) {
    console.error("❌ Error setting up listener:", error);
    return null;
  }
};

export const updateUserProgress = async (userId, data) => {
  try {
    await updateDoc(doc(db, 'userProgress', userId), data);
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const addQuizResult = async (userId, quizData) => {
  try {
    // ✅ FIXED: Filter out undefined values from quizData before passing to arrayUnion
    // This prevents Firebase errors about unsupported field values
    const cleanQuizData = Object.fromEntries(
      Object.entries(quizData).filter(([_, v]) => v !== undefined)
    );
    
    // ✅ FIXED: Now includes currentStreak and lastActiveDate
    await setDoc(
      doc(db, 'userProgress', userId),
      {
        quizHistory: arrayUnion(cleanQuizData),  // ✅ Uses clean data without undefined
        quizzesCompleted: quizData.quizzesCompleted,
        totalPoints: quizData.totalPoints,
        currentStreak: quizData.currentStreak || 0,  // ✅ Save streak
        lastActiveDate: quizData.lastActiveDate || new Date().toISOString().split('T')[0],  // ✅ Save date
        lastUpdated: new Date(),  // ✅ Timestamp for debugging
        achievements: quizData.achievements || [],
        verseProgress: quizData.verseProgress || {},
      },
      { merge: true }
    );

    console.log("✅ Quiz result saved with streak:", quizData.currentStreak);
    return { success: true };
  } catch (error) {
    console.error("❌ Error saving quiz result:", error);
    return { success: false, error: error.message };
  }
};

// Archive a S.H.A.R.P. dialog session for later recall
export const addSharpDialog = async (userId, dialog) => {
  try {
    const clean = Object.fromEntries(Object.entries(dialog || {}).filter(([_, v]) => v !== undefined));
    await setDoc(
      doc(db, 'userProgress', userId),
      {
        sharpHistory: arrayUnion(clean),
        lastUpdated: new Date()
      },
      { merge: true }
    );
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};