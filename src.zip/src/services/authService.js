import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged
} from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { auth, db } from './firebase';

// ✅ EXISTING EMAIL SIGN-UP FUNCTION
export const signUp = async (email, password, name) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    
    // Create user document in Firestore
    await setDoc(doc(db, 'users', user.uid), {
      name,
      email,
      createdAt: new Date(),
      selectedTranslation: 'NKJV',
      includeApocrypha: false
    });
    
    // Initialize user progress
    await setDoc(doc(db, 'userProgress', user.uid), {
      versesMemorized: [],
      quizzesCompleted: 0,
      currentStreak: 0,
      lastActiveDate: new Date(),
      totalPoints: 0,
      achievements: [],
      quizHistory: []
    });
    
    return { success: true, user };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// ✅ EXISTING EMAIL SIGN-IN FUNCTION
export const signIn = async (email, password) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return { success: true, user: userCredential.user };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// ✅ EXISTING SIGN-OUT FUNCTION
export const signOut = async () => {
  try {
    await firebaseSignOut(auth);
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// ✅ EXISTING AUTH STATE LISTENER
export const onAuthChange = (callback) => {
  return onAuthStateChanged(auth, callback);
};
